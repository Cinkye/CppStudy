#include <iostream>
#include <string>
#include "Library.h"

using namespace std;

int main()
{
    int bookNum = 0;
    cin >> bookNum;
    Library s(bookNum);
    return 0;
}
