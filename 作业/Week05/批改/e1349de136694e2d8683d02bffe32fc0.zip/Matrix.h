#ifndef MATRIX_H
#define MATRIX_H


#include<iostream>
using namespace std;
class Matrix
{
	friend ostream &operator<<( ostream &, Matrix&);
	friend istream &operator >> (istream&, Matrix&);
public:
	Matrix();
	bool operator!=(const Matrix&right)const
	{
		return!(*this == right);
	}
	bool operator ==(const Matrix&)const;
	
	Matrix operator+=(const Matrix&);
	Matrix operator-=(const Matrix&);
	Matrix  operator*=(Matrix&);
	Matrix operator+(const Matrix&)const;
	Matrix operator-(const Matrix&)const;
	Matrix operator*(const Matrix&)const;
friend Matrix operator*( Matrix&, double);
	
private:
	double a;
	double b;
	double c;
	double d;
};
#endif // !MATRIX_H