#include"Matrix.h"
#include<iostream>
#include<cstdlib>
#include<iomanip>
using namespace std;

bool Matrix:: operator ==(const Matrix&right)const
{
	if (a == right.a&&b == right.b&&c == right.c&&d == right.d)
		return true;
	else
		return false;

}
Matrix::Matrix() :a(1), b(0), c(0), d(1)//��ʼ������ʼ���������ݳ�Ա
{
	cout << "It has been initialized to the identity matrix" << endl;
}
ostream&operator<<(ostream &output, Matrix& m)
{
	output << m.a << setw(5) << m.b  <<endl<< m.c << setw(5) << m.d << endl;
	return output;
}
istream&operator >> (istream&input, Matrix&m)
{
	input >> m.a >> m.b >> m.c >> m.d;
	return input;
}
 Matrix Matrix::operator+(const Matrix&m)const
{
	Matrix sum;
	sum.a = this->a + m.a;
	sum.b = this->b + m.b;
	sum.c = this->c + m.c;
	sum.d = this->d + m.d;
	return sum;

}
 Matrix Matrix::operator-(const Matrix&m)const
{
	Matrix diff;
	diff.a= this->a - m.a;
	diff.b= this->b - m.b;
	diff.c= this->c -m.c;
	diff.d= this->d - m.d;
	return diff;
}
 Matrix Matrix::operator*(const Matrix&m)const
 {
	 Matrix result;
	 result.a = this->a*m.a + this->b*m.c;
	 result.b = this->a*m.b + this->b*m.d;
	 result.c = this->c*m.a + this->d*m.c;
	 result.d = this->c*m.b + this->d*m.d;
	 return result;
 }
 Matrix operator*(Matrix&m, double i)
 {
	 m.a = i*m.a;
	 m.b = i*m.b;
	 m.c = i*m.c;
	 m.d = i*m.d;
	 return m;
}
 Matrix Matrix::operator+=(const Matrix&m)
 {
	 this->a = this->a + m.a;
	 this->b = this->b + m.b;
	 this->c = this->c + m.c;
	 this->d = this ->d + m.d;
	 return *this;
 }
Matrix Matrix::operator-=(const Matrix&m)
 {
	 this->a = this->a - m.a;
	 this->b = this->b - m.b;
	 this->c = this->c - m.c;
	 this->d = this->d - m.d;
	 return *this;
 }
 Matrix Matrix::operator*=(Matrix&m)
 {
	 this->a= this->a*m.a + this->b*m.c;
	 this->b = this->a*m.b + this->b*m.d;
	 this->c = this->c*m.a + this->d*m.c;
	 this->d = this->c*m.b + this->d*m.d;
	 return *this;
 }