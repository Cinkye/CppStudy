//Exercise 2.21 Displaying Shapes with Asterisks
//2017.10.30
#include<iostream>
using namespace std;

int main()
    {
        cout << "*********             ***                 *                *\n";
        cout << "*       *           *     *              ***              * *\n";
        cout << "*       *          *       *            *****            *   *\n";
        cout << "*       *          *       *              *             *     *\n";
        cout << "*       *          *       *              *            *       *\n";
        cout << "*       *          *       *              *             *     *\n";
        cout << "*       *          *       *              *              *   *\n";
        cout << "*       *           *     *               *               * *\n";
        cout << "*********             ***                 *                *\n";
        cin.get();
        return 0;
    }
