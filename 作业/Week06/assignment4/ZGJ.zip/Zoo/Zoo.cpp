#include "zoo.h"

namespace ZOO
{
	//-------------------------static������-------------------------------------
	int ZooSimulation::_nextID = 100000;
	Money FoodSeller::_foodPrice[]
	{
		_foodPrice[0] = Money(0, 20),
		_foodPrice[1] = Money(0, 30),
		_foodPrice[2] = Money(0, 50)
	};
	const Money Zoo::_adultPrice = Money(1, 0);
	const Money Zoo::_childPrice = Money(0, 40);
	int Adult::_number = 0;
	int Child::_number = 0;
	const int Animal::_foodCapacity[animalTypeNumbers] = { 750, 500, 300 };
	//--------------------------------------------------------------------------


	Zoo::Zoo()
	{
		cout << "A New Zoo has created ! ! ! ! ! ! ! " << endl << endl;
		_zooKeeper = new ZooKeeper;
		_foodSeller = new FoodSeller;
		_elephant = new Elephant;
		_giraffe = new Giraffe[2];
		_monkey = new Monkey[3];
	}

	Zoo::~Zoo()
	{
		delete _zooKeeper;
		delete _foodSeller;
		delete _elephant;
		delete[] _giraffe;
		delete[] _monkey;
		cout << "Bye." << endl;
	}

	void Zoo::checkOpen()
	{
		bool allopen = 1;
		SetColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);

		if (!(_elephant->_encosure.isopen()))
		{
			allopen = 0;
			cout << "Today, elephant encosure is closed." << endl << endl;
		}

		int gNopen = 0;
		if (!(_giraffe[0]._encosure.isopen()))
		{
			allopen = 0;
			gNopen++;
		}
		if (!(_giraffe[1]._encosure.isopen()))
		{
			allopen = 0;
			gNopen++;
		}
		if (gNopen == 1)
			cout << "Today, one of giraffe encosure is closed." << endl << endl;
		if (gNopen == 2)
			cout << "Today, all of giraffe encosures are closed." << endl << endl;

		int mNopen = 0;
		if (!(_monkey[0]._encosure.isopen()))
		{
			allopen = 0;
			mNopen++;
		}
		if (!(_monkey[1]._encosure.isopen()))
		{
			allopen = 0;
			mNopen++;
		}
		if (!(_monkey[2]._encosure.isopen()))
		{
			allopen = 0;
			mNopen++;
		}
		if (mNopen == 1)
			cout << "Today, one of monkey encosure is closed." << endl << endl;
		if (mNopen == 2)
			cout << "Today, two of monkey encosures are closed." << endl << endl;
		if (mNopen == 3)
			cout << "Today, all of monkey encosures are closed." << endl << endl;

		SetColor(FOREGROUND_GREEN | FOREGROUND_INTENSITY);
		if (allopen)
		{
			cout << "Today, all of animal encosures are open." << endl << endl;
		}
		SetColor();
	}

	void Zoo::checkDirtLevel()
	{
		bool hasdirty = 0;
		SetColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);
		cout << "The zoo keeper checks the dirt level of each animal enclosure." << endl;

		if (_elephant->_encosure.getDirtLevel() >= Max_dirt)
		{
			hasdirty = 1;
			_elephant->_encosure.closeit();
			_tobeCleaned[numoftobeCleaned++] = &(_elephant->_encosure);
			cout << "Elephant encosure is too dirty." << endl;
		}
		if (_giraffe[0]._encosure.getDirtLevel() >= Max_dirt)
		{
			hasdirty = 1;
			_giraffe[0]._encosure.closeit();
			_tobeCleaned[numoftobeCleaned++] = &(_giraffe[0]._encosure);
			cout << "Giraffe 1 encosure is too dirty." << endl;
		}
		if (_giraffe[1]._encosure.getDirtLevel() >= Max_dirt)
		{
			hasdirty = 1;
			_giraffe[1]._encosure.closeit();
			_tobeCleaned[numoftobeCleaned++] = &(_giraffe[1]._encosure);
			cout << "Giraffe 2 encosure is too dirty." << endl;
		}
		if (_monkey[0]._encosure.getDirtLevel() >= Max_dirt)
		{
			hasdirty = 1;
			_monkey[0]._encosure.closeit();
			_tobeCleaned[numoftobeCleaned++] = &(_monkey[0]._encosure);
			cout << "Monkey 1 encosure is too dirty." << endl;
		}
		if (_monkey[1]._encosure.getDirtLevel() >= Max_dirt)
		{
			hasdirty = 1;
			_monkey[1]._encosure.closeit();
			_tobeCleaned[numoftobeCleaned++] = &(_monkey[1]._encosure);
			cout << "Monkey 2 encosure is too dirty." << endl;
		}
		if (_monkey[2]._encosure.getDirtLevel() >= Max_dirt)
		{
			hasdirty = 1;
			_monkey[2]._encosure.closeit();
			_tobeCleaned[numoftobeCleaned++] = &(_monkey[2]._encosure);
			cout << "Monkey 3 encosure is too dirty." << endl;
		}

		SetColor(FOREGROUND_GREEN | FOREGROUND_INTENSITY);
		if (!hasdirty)
		{
			cout << "All fine." << endl;
		}
		SetColor();
	}

	void Zoo::clean()
	{
		_tobeCleaned[numoftobeCleaned]->openit();
		numoftobeCleaned--;
		_zooKeeper->add();
	}

	void Zoo::makeMoney(Money m)
	{
		_income += m;
	}

	Money Zoo::getIncome()
	{
		return _income;
	}

	Money::Money()
	{
	}

	Money::Money(int d, int c)
	{
		_dollar = c / 100 + d;
		_cent = c % 100;
	}


	Money::~Money()
	{
	}

	Money Money::operator+(Money const & right) const
	{
		Money add;
		add._cent = _cent + right._cent;
		add._dollar = add._cent / 100 + _dollar + right._dollar;
		add._cent %= 100;
		return add;
	}

	Money Money::operator*(int r) const
	{
		if (r == 0)
		{
			return Money(0, 0);
		}
		Money pro(0,0);
		for (int i = 0; i < r; ++i)
		{
			pro = pro + *this;
		}
		return pro;
	}

	Money Money::operator-(Money const & right) const
	{
		if (_dollar < right._dollar || (_dollar == right._dollar && _cent < right._cent))
		{
			std::cerr << " ERROR " << std::endl;
			return Money(-1, -1);
		}
		Money dif;
		dif._cent = _cent - right._cent;
		dif._dollar = _dollar - right._dollar;
		if (dif._cent < 0)
		{
			dif._dollar--;
			dif._cent += 100;
		}
		return dif;
	}

	Money & Money::operator+=(Money const & right)
	{
		*this = *this + right;
		return *this;
	}

	Money & Money::operator-=(Money const & right)
	{
		*this = *this - right;
		return *this;
	}

	Money & Money::operator*=(int right)
	{
		*this = *this * right;
		return *this;
	}

	double Money::operator/(Money const & right) const
	{
		double c1 = 0, c2 = 0;
		c1 = _cent + _dollar * 100;
		c2 = right._cent + right._dollar * 100;
		double div = c1 / c2;
		return div;
	}

	Money Money::operator/(int right) const
	{
		int cent = (_cent + _dollar * 100) / right;
		return Money(0, cent);
	}

	std::ostream & operator << (std::ostream & os, const Money & m)
	{
		if (m._dollar != 0 && m._cent != 0)
		{
			os << m._dollar;
			if (m._dollar != 1)
				os << " dollars and ";
			else
				os << " dollar and ";
			if (m._cent != 1)
				os << m._cent << " cents";
			else
				os << m._cent << " cent";
		}
		else if (m._dollar != 0 && m._cent == 0)
		{
			os << m._dollar;
			if (m._dollar != 1)
				os << " dollars";
			else
				os << " dollar";
		}
		else if (m._dollar == 0 && m._cent != 0)
		{
			if (m._cent != 1)
				os << m._cent << " cents";
			else
				os << m._cent << " cent";
		}
		else
		{
			os << "no money";
		}
		return os;
	}


	AnimalFood::AnimalFood()
	{
	}

	AnimalFood::AnimalFood(ANIMALFOOD t, double a)
		:_type(t), _amount(a)
	{
	}


	AnimalFood::~AnimalFood()
	{
	}

	AnimalFood::ANIMALFOOD AnimalFood::getType()
	{
		return _type;
	}

	int AnimalFood::getAmounts() const
	{
		return _amount;
	}


	AnimalEncosure::AnimalEncosure()
	{
	}


	AnimalEncosure::~AnimalEncosure()
	{
	}

	AnimalEncosure & AnimalEncosure::operator+=(const int right)
	{
		_dirtLevel += right;
		return *this;
	}

	int AnimalEncosure::getDirtLevel()
	{
		return _dirtLevel;
	}

	void AnimalEncosure::makeMess()
	{
		_dirtLevel++;
	}

	bool AnimalEncosure::isopen() const
	{
		return _isopen;
	}


	Animal::Animal()
	{
		cout << "A new animal!" << endl;
	}

	Animal::Animal(double w)
		:_weight(w)
	{
		cout << "A new animal!" << endl;
	}


	Animal::~Animal()
	{
	}

	void feed(Animal & animal, AnimalFood animalFood)
	{
		animal._foodEaten += animalFood.getAmounts();
		if (animal.makeMess())
		{
			SetColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE, BACKGROUND_RED);
			cout << "There an animal makes a mass." << endl;
			SetColor();
		}
	}

	void Animal::reset()
	{
		_foodEaten = 0;
	}


	Elephant::Elephant()
	{
		cout << "It's an elephant." << endl;
		_weight = randomInt(500, 2000);
		_trunkLength = randomDouble();
		cout << "Its weight is " << _weight << "KG, and its trunk length is " << _trunkLength << "m." << endl << endl;
	}

	Elephant::Elephant(double weight, double trunk)
		:Animal(weight), _trunkLength(trunk)
	{
		cout << "It's an elephant." << endl;
		cout << "Its weight is " << _weight << "KG, and its trunk length is " << _trunkLength << "m." << endl << endl;
	}


	Elephant::~Elephant()
	{
	}

	bool Elephant::makeMess()
	{
		if (_foodEaten >= _foodCapacity[0])
		{
			reset();
			_encosure.makeMess();
			return true;
		}
		return false;
	}


	Giraffe::Giraffe()
	{
		cout << "It's a giraffe." << endl;
		_weight = randomInt(50, 500);
		_neckLength = randomDouble();
		cout << "Its weight is " << _weight << "KG, and its neck length is " << _neckLength << "m." << endl << endl;
	}

	Giraffe::Giraffe(double weight, double neck)
		:Animal(weight), _neckLength(neck)
	{
		cout << "It's a giraffe." << endl;
		cout << "Its weight is " << _weight << "KG, and its neck length is " << _neckLength << "m." << endl << endl;
	}


	Giraffe::~Giraffe()
	{
	}

	bool Giraffe::makeMess()
	{
		if (_foodEaten >= _foodCapacity[1])
		{
			reset();
			_encosure.makeMess();
			return true;
		}
		return false;
	}


	Monkey::Monkey()
	{
		cout << "It's a monkey." << endl;
		_weight = randomInt(10, 100);
		_armLength = randomDouble();
		cout << "Its weight is " << _weight << "KG, and its arm length is " << _armLength << "m." << endl << endl;
	}

	Monkey::Monkey(double weight, double arm)
		:Animal(weight), _armLength(arm)
	{
		cout << "It's a monkey." << endl;
		cout << "Its weight is " << _weight << "KG, and its arm length is " << _armLength << "m." << endl << endl;
	}


	Monkey::~Monkey()
	{
	}

	bool Monkey::makeMess()
	{
		if (_foodEaten >= _foodCapacity[2])
		{
			reset();
			_encosure.makeMess();
			return true;
		}
		return false;
	}


	Person::Person()
	{
	}


	Person::~Person()
	{
	}

	string Person::getName() const
	{
		return _name;
	}

	void Person::setName(string str)
	{
		_name = str;
	}

	int Person::getAge() const
	{
		return _age;
	}

	void Person::setAge(int age)
	{
		_age = age;
	}

	void Person::initialize(int len)
	{
		setName(randomString(len));
		setAge(randomInt(18, 45));
		cout << "His name is " << getName() << ", and his age is " << getAge() << "." << endl;
	}


	ZooKeeper::ZooKeeper()
	{
		cout << "We have a new zoo keeper." << endl;
		initialize(10);
		cout << "He will be a good worker." << endl << endl;
	}


	ZooKeeper::~ZooKeeper()
	{
	}

	bool ZooKeeper::judgeQuit()
	{
		SetColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE, BACKGROUND_RED);
		if (_days_cleaning_enclosures >= 11)
		{
			cout << " The zoo keeper has quit after 10 days of cleaning." << endl;
			_isquit = 1;
			return true;
		}
		SetColor();
		return false;
	}

	void ZooKeeper::add()
	{
		_days_cleaning_enclosures++;
	}


	FoodSeller::FoodSeller()
	{
		cout << "We have a new food seller." << endl;
		initialize(15);
		cout << "He will be a good worker." << endl << endl;
	}


	FoodSeller::~FoodSeller()
	{
	}

	void FoodSeller::makeMoney(Money m)
	{
		_income += m;
	}

	Money FoodSeller::getIncome()
	{
		return _income;
	}

	void FoodSeller::displayAmount() const
	{
		cout << "Food seller has " << _amount[0];
		if (_amount[0] == 1)
			cout << " peanut, " << _amount[1];
		else
			cout << " peanuts, " << _amount[1];
		if (_amount[1] == 1)
			cout << " carrot and " << _amount[2];
		else
			cout << " carrot and " << _amount[2];
		if (_amount[2] == 1)
			cout << " Banana." << endl << endl;
		else
			cout << " Bananas." << endl << endl;
	}


	Visitor::Visitor()
	{
		_ID = -1;
	}

	Visitor::Visitor(int id)
		:_ID(id)
	{
		cout << "A new visitor is coming, whose ID is " << _ID << "." << endl;
	}


	Visitor::~Visitor()
	{
	}

	void Visitor::setID(int id)
	{
		_ID = id;
	}

	int Visitor::getID() const
	{
		return _ID;
	}

	void Visitor::displayLeaveMessage()
	{
		cout << "Visitor " << _ID << " leave the zoo." << endl;
	}


	Child::Child()
	{
		_foods = new AnimalFood[3];
	}

	Child::Child(int id)
		:Visitor(id)
	{
		cout << "He is a child." << endl;
		initialize(6);
		_number++;
		_foods = new AnimalFood[3];
	}

	Child::Child(Child & c)
	{
		setID(c.getID());
		setName(c.getName());
		setAge(c.getAge());
		_foods = new AnimalFood[3];
		for (int i = 0; i < 3; ++i)
		{
			_foods[i] = c._foods[i];
		}
	}

	Child & Child::operator=(Child & c)
	{
		setID(c.getID());
		setName(c.getName());
		setAge(c.getAge());
		_foods = new AnimalFood[3];
		for (int i = 0; i < 3; ++i)
		{
			_foods[i] = c._foods[i];
		}
		return *this;
	}


	Child::~Child()
	{
		delete[] _foods;
	}

	void Child::displayLeaveMessage()
	{
		cout << "Child " << getID() << " leave the zoo." << endl;
	}

	void Child::initialize(int len)
	{
		setName(randomString(len));
		setAge(randomInt(3, 18));
		cout << "His name is " << getName() << ", and his age is " << getAge() << "." << endl;
	}


	Adult::Adult(int id)
		:Visitor(id)
	{
		cout << "He is an adult." << endl;
		initialize(9);
		_number++;
		int dollars = randomInt(Minimum_number_of_money, Maximum_number_of_money);
		_money = new Money(dollars, 0);
		cout << "He has " << (*_money)  << "." << endl;
		_children_num = randomInt(Minimum_number_of_children, Maximum_number_of_children);
		if (_children_num == 1)
			cout << "And he has " << _children_num << " child." << endl;
		else
			cout << "And he has " << _children_num << " children." << endl;
		
		_children = new Child[_children_num];
		for (int i = 0; i < _children_num; ++i)
		{
			Child child(ZooSimulation::getNextID());
			_children[i] = child;
		}
	}


	Adult::~Adult()
	{
		for (int i = 0; i < _children_num; ++i)
		{
			_children[i].displayLeaveMessage();
		}
		delete[] _children;
		delete _money;
		displayLeaveMessage();
	}

	Money Adult::buyt()
	{
		Money m;
		m = Zoo::_adultPrice + Zoo::_childPrice * _children_num;
		cout << "Then the adult spend " << m << " to buy tickets." << endl;
		*_money -= m;
		cout << "Ops, now he has " << (*_money) << "." << endl;
		return m;
	}

	Money Adult::buyfood(FoodSeller & seller)
	{
		Money buyfood = *_money / 3;
		Money cost = buyfood * 3;
		double num1 = buyfood / FoodSeller::_foodPrice[0] / _children_num;
		double num2 = buyfood / FoodSeller::_foodPrice[1] / _children_num;
		double num3 = buyfood / FoodSeller::_foodPrice[2] / _children_num;
		AnimalFood food[3]
		{
			AnimalFood(AnimalFood::Peanuts, num1),
			AnimalFood(AnimalFood::Carrots, num2),
			AnimalFood(AnimalFood::Bananas, num3)
		};
		for (int i = 0; i < _children_num; ++i)
		{
			for (int j = 0; j < 3; ++j)
			{
				if(buyFood(seller, food[j]))
					_children[i]._foods[j] = food[j];
				else
				{
					SetColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE, BACKGROUND_RED);
					switch (j)
					{
					case 0:
						cout << "Adult try to buy peanuts, but the seller doesn't have enough!" << endl;
						break;
					case 1:
						cout << "Adult try to buy carrots, but the seller doesn't have enough!" << endl;
						break;
					case 2:
						cout << "Adult try to buy bananas, but the seller doesn't have enough!" << endl;
						break;
					default:
						break;
					}
					SetColor();
					cost = cost - (buyfood / _children_num);
					_children[i]._foods[j] = AnimalFood((AnimalFood::ANIMALFOOD)j, 0);
				}
			}
		}
		cout << "The adult's money has been divided evenly to buy the 3 types of animal food." << endl;
		cout << "He uses " << cost << " to buy each type of food." << endl;

		*_money -= cost;
		cout << "Ops, now the adult has " << (*_money) << "." << endl;
		return cost;
	}

	
	void Adult::displayLeaveMessage()
	{
		cout << "Adult " << getID() << " leave the zoo." << endl << endl;
	}

	int Adult::getChNum() const
	{
		return _children_num;
	}

	
	void ZooSimulation::runSimulation(int days = 9999)
	{
		SetColor(FOREGROUND_INTENSITY | FOREGROUND_RED, BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE | BACKGROUND_INTENSITY);
		cout << endl << "Zoo Simulation has started" << endl << endl;
		SetColor();

		_zoo = new Zoo;
		int i = 1;
		for (; i <= days; ++i)
		{
			SetColor(FOREGROUND_BLUE | FOREGROUND_INTENSITY, BACKGROUND_INTENSITY);
			cout << endl;
			cout << "########################" << endl;
			cout << "#                      #" << endl;
			cout << "#        DAY " << std::setw(5) << i << "     #" << endl;
			cout << "#                      #" << endl;
			cout << "########################" << endl << endl;
			SetColor();
			_zoo->checkOpen();
			_zoo->_foodSeller->displayAmount();
			runOneDay();

			SetColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE, BACKGROUND_RED);
			if (_zoo->_foodSeller->_runout[0])
			{
				cout << "The zoo closed because the seller ran out of peanuts." << endl;
				break;
			}
			if (_zoo->_foodSeller->_runout[1])
			{
				cout << "The zoo closed because the seller ran out of carrots." << endl;
				break;
			}
			if (_zoo->_foodSeller->_runout[2])
			{
				cout << "The zoo closed because the seller ran out of bananas." << endl;
				break;
			}
			SetColor();

			_zoo->checkDirtLevel();
			if (_zoo->numoftobeCleaned != 0)
				_zoo->clean();
			_zoo->_zooKeeper->judgeQuit();
			SetColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE, BACKGROUND_RED);
			if (_zoo->_zooKeeper->_isquit)
			{
				cout << "The zoo closed because the zoo keeper had enough of cleaning and quit!" << endl;
				break;
			}
			SetColor();
		}

		SetColor(FOREGROUND_RED | FOREGROUND_INTENSITY, BACKGROUND_INTENSITY);
		cout << endl<< "Information Summary" << endl;
		cout << "The number of days the zoo was opened for: " << i << endl << endl;
		cout << "The total number of adult visitors: " << Adult::_number << " and the total number of children: " << Child::_number << "." << endl;
		cout << endl << "During these days, the income from tickets is " << _zoo->getIncome() << "." << endl;
		cout << "And the income from food is " << _zoo->_foodSeller->getIncome() << "." << endl;
		cout << "And the total amount of money is " << _zoo->getIncome() + _zoo->_foodSeller->getIncome() << "." << endl << endl;

		cout << "The number of days elephant enclosure was closed for: " << _zoo->_elephant[0]._encosure._daysClosed << "." << endl;
		cout << "The number of days giraffe 1 enclosure was closed for: " << _zoo->_giraffe[0]._encosure._daysClosed << "." << endl;
		cout << "The number of days giraffe 2 enclosure was closed for: " << _zoo->_giraffe[1]._encosure._daysClosed << "." << endl;
		cout << "The number of days monkey 1 enclosure was closed for: " << _zoo->_monkey[0]._encosure._daysClosed << "." << endl;
		cout << "The number of days monkey 2 enclosure was closed for: " << _zoo->_monkey[1]._encosure._daysClosed << "." << endl;
		cout << "The number of days monkey 3 enclosure was closed for: " << _zoo->_monkey[2]._encosure._daysClosed << "." << endl << endl;
		SetColor();
		
		delete _zoo;
		SetColor(FOREGROUND_INTENSITY | FOREGROUND_RED, BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE | BACKGROUND_INTENSITY);
		cout << endl << "Zoo Simulation has ended";
		SetColor();
		cout << endl;
	}
	void ZooSimulation::runOneDay()
	{
		int adultnum = randomInt(Minimum_number_of_adults, Maximum_number_of_adults);
		for (int i = 0; i < adultnum; ++i)
		{
			Adult adult(this->getNextID());
			_zoo->makeMoney(adult.buyt());
			_zoo->_foodSeller->makeMoney(adult.buyfood(*(_zoo->_foodSeller)));
			SetColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE, BACKGROUND_RED);
			for (int i = 0; i < adult.getChNum(); ++i)
			{
				if (_zoo->_elephant[0]._encosure.isopen())
				{
					feed(_zoo->_elephant[0], adult._children[i]._foods[0]);
				}
				else
				{
					cout << "Elephant encosure is closed, which lead to the fealure of feed." << endl;
				}
				if (_zoo->_giraffe[0]._encosure.isopen())
				{
					feed(_zoo->_giraffe[0], adult._children[i]._foods[1]);
				}
				else if (_zoo->_giraffe[1]._encosure.isopen())
				{
					feed(_zoo->_giraffe[1], adult._children[i]._foods[1]);
				}
				else
				{
					cout << "All giraffe encosures are closed, which lead to the fealure of feed." << endl;
				}
				if (_zoo->_monkey[0]._encosure.isopen())
				{
					feed(_zoo->_monkey[0], adult._children[i]._foods[2]);
				}
				else if (_zoo->_monkey[1]._encosure.isopen())
				{
					feed(_zoo->_monkey[1], adult._children[i]._foods[2]);
				}
				else if (_zoo->_monkey[2]._encosure.isopen())
				{
					feed(_zoo->_monkey[2], adult._children[i]._foods[2]);
				}
				else
				{
					cout << "All monkey encosures are closed, which lead to the fealure of feed." << endl;
				}
				SetColor();
			}
		}
	}
	void ZooSimulation::start()
	{
		int a;
		cout << "Enter 1 to start the Zoo Simulation: " << endl;
		SetColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
		cout << "FBI Warning ! ! !" << endl;
		SetColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);
		cout << "When you type 1, it produces a lot of output." << endl;
		if (!(std::cin >> a) || a != 1)
		{
			SetColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE, BACKGROUND_RED);
			cout << "�ݰݡ�" << endl;
			SetColor();
		}
		else
			runSimulation();
	}
	int ZooSimulation::getNextID()
	{
		return ++_nextID;
	}

	int  randomInt(int s, int e)
	{
		int age = randEx() % (e - s + 1) + s;
		return age;
	}
	double  randomDouble(double s, double e)
	{
		int i = randEx() % (int)(e - s + 1) + s;
		double d = randEx() / (RAND_MAX + 0.0);
		return i + d;
	}
	inline int randEx()
	{
		LARGE_INTEGER seed;
		QueryPerformanceFrequency(&seed);
		QueryPerformanceCounter(&seed);
		srand(seed.QuadPart);

		return rand();
	}
	string randomString(int len)
	{
		char * a = new char[len];
		for (int i = 0; i < len; ++i)
		{
			a[i] = (char)(randomInt(97, 122));
		}
		a[0] -= 32;
		string ran = a;
		delete[] a;
		return ran.substr(0,len);
	}
	void SetColor(unsigned short forecolor, unsigned short backgroudcolor)
	{
		HANDLE hCon = GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleTextAttribute(hCon, forecolor | backgroudcolor);
	}

	bool buyFood(FoodSeller & seller, AnimalFood food)
	{
		if (food.getAmounts() <= seller._amount[food.getType()])
		{
			seller._amount[food.getType()] -= food.getAmounts();
			return true;
		}
		else
		{
			seller._runout[food.getType()] = 1;
			return false;
		}
	}
	
}
