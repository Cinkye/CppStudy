#include "zoo.h"
using namespace std;
using namespace ZOO;

int main()
{
	ZooSimulation zs;
	zs.start();
	system("pause");
	return 0;
}